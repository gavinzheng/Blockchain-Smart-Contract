# Getting started


```
$ sudo docker-compose build
$ sudo docker-compose up -d
```

Start geth in light mode and expose to port 8546.