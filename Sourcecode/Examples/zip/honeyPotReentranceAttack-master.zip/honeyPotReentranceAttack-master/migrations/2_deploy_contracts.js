var HoneyPot = artifacts.require("./HoneyPot.sol");

module.exports = function(deployer) {
 deployer.deploy(HoneyPot)
};
