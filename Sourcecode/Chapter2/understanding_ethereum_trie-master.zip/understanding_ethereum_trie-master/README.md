understanding_ethereum_trie
===========================
Repo supporting blog post at http://easythereentropy.wordpress.com/2014/06/04/understanding-the-ethereum-trie/

Hopefully, this will help those confused soles who have yet to grasp the trie.
