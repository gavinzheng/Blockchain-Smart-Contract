# Ethereum Voting Dapp
Simple Ethereum Voting dapp using Truffle framework

## Usage
The below blog posts explain each chapter in detail:

Chapter 1: https://medium.com/@mvmurthy/full-stack-hello-world-voting-ethereum-dapp-tutorial-part-1-40d2d0d807c2#.yqxqj0hff

Chapter 2: https://medium.com/@mvmurthy/full-stack-hello-world-voting-ethereum-dapp-tutorial-part-2-30b3d335aa1f

Chapter 3: https://medium.com/@mvmurthy/full-stack-hello-world-voting-ethereum-dapp-tutorial-part-3-331c2712c9df#.ldky416p7

Chapter 4: https://medium.com/zastrin/how-to-save-your-ethereum-dapp-users-from-paying-gas-for-transactions-abd72f15e14d
