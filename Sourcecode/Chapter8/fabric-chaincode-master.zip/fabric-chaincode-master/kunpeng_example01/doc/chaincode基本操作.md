## 什么是chaincode

chaincode是fabric的智能合约，又叫做链码。Chaincode是生成transacton的唯一方式，是外界与区块链系统交互的唯一渠道，开发Fabric区块链应用就是要编写Chaincode, Chaincode就是业务逻辑实现。

## chaincode生命周期

* Install 安装

  chaincode 要在 Fabric 网络上运行，必须要先安装在网络中的 peer 上，安装同时注明版本号保证应用的版本控制。

* Instantiate实例化

  在 peer 上安装 chaincode 后，还需要实例化才能真正激活该 chaincode 。在实例化的过程中，chaincode 就会被编译并打包成docker容器镜像，然后启动运行。每个应用只能被实例化一次，实例化可在任意一个已安装该 chaincode 的 peer 上进行。

* Invoke调用，Query查询

  chaincode 在实例化后，用户就能与它进行交互，其中 query 查询与应用相关的状态（即只读），而 invoke 则可能会改变其状态。

* Upgrade升级

  在 chaincode更新代码后，需要把新的代码通过install交易安装到正在运行该 chaincode的 peer 上，安装时需注明比先前版本更高的版本号，接下来向任意一个安装了新代码的 peer 发送 upgrade 交易就能更新 chaincode，chaincode 在更新前的状态也会得到保留。

## first network示例

现在，我们在first network的环境中，重新部署一个新的应用，应用逻辑是插入一个学生的成绩（学生姓名，语文成绩，数学成绩），然后计算总成绩记录到链上，通过学生姓名查询学生的总成绩。



## fabric-sample 修改tls为false

### 修改first-network/docker-compose-cli.yaml

找到CORE_PEER_TLS_ENABLED=true，修改为CORE_PEER_TLS_ENABLED=false，如下：

``` yml
cli:
    container_name: cli
    image: hyperledger/fabric-tools:$IMAGE_TAG
    tty: true
    stdin_open: true
    environment:
      - GOPATH=/opt/gopath
      - CORE_VM_ENDPOINT=unix:///host/var/run/docker.sock
      #- FABRIC_LOGGING_SPEC=DEBUG
      - FABRIC_LOGGING_SPEC=INFO
      - CORE_PEER_ID=cli
      - CORE_PEER_ADDRESS=peer0.org1.example.com:7051
      - CORE_PEER_LOCALMSPID=Org1MSP
      - CORE_PEER_TLS_ENABLED=false
```



### 修改first-network/base/peer-base.yaml 

找到CORE_PEER_TLS_ENABLED=true改为CORE_PEER_TLS_ENABLED=false

找到ORDERER_GENERAL_TLS_ENABLED=true改为ORDERER_GENERAL_TLS_ENABLED=false

如下：

```yml
peer-base:
    image: hyperledger/fabric-peer:$IMAGE_TAG
    environment:
      - CORE_VM_ENDPOINT=unix:///host/var/run/docker.sock
      # the following setting starts chaincode containers on the same
      # bridge network as the peers
      # https://docs.docker.com/compose/networking/
      - CORE_VM_DOCKER_HOSTCONFIG_NETWORKMODE=${COMPOSE_PROJECT_NAME}_byfn
      - FABRIC_LOGGING_SPEC=INFO
      #- FABRIC_LOGGING_SPEC=DEBUG
      - CORE_PEER_TLS_ENABLED=false
      - CORE_PEER_GOSSIP_USELEADERELECTION=true
      - CORE_PEER_GOSSIP_ORGLEADER=false
      - CORE_PEER_PROFILE_ENABLED=true
      - CORE_PEER_TLS_CERT_FILE=/etc/hyperledger/fabric/tls/server.crt
      - CORE_PEER_TLS_KEY_FILE=/etc/hyperledger/fabric/tls/server.key
      - CORE_PEER_TLS_ROOTCERT_FILE=/etc/hyperledger/fabric/tls/ca.crt
    working_dir: /opt/gopath/src/github.com/hyperledger/fabric/peer
    command: peer node start

  orderer-base:
    image: hyperledger/fabric-orderer:$IMAGE_TAG
    environment:
      - FABRIC_LOGGING_SPEC=INFO
      - ORDERER_GENERAL_LISTENADDRESS=0.0.0.0
      - ORDERER_GENERAL_GENESISMETHOD=file
      - ORDERER_GENERAL_GENESISFILE=/var/hyperledger/orderer/orderer.genesis.block
      - ORDERER_GENERAL_LOCALMSPID=OrdererMSP
      - ORDERER_GENERAL_LOCALMSPDIR=/var/hyperledger/orderer/msp
      # enabled TLS
      - ORDERER_GENERAL_TLS_ENABLED=false
      - ORDERER_GENERAL_TLS_PRIVATEKEY=/var/hyperledger/orderer/tls/server.key
      - ORDERER_GENERAL_TLS_CERTIFICATE=/var/hyperledger/orderer/tls/server.crt
      - ORDERER_GENERAL_TLS_ROOTCAS=[/var/hyperledger/orderer/tls/ca.crt]
      - ORDERER_KAFKA_TOPIC_REPLICATIONFACTOR=1
      - ORDERER_KAFKA_VERBOSE=true
      - ORDERER_GENERAL_CLUSTER_CLIENTCERTIFICATE=/var/hyperledger/orderer/tls/server.crt
      - ORDERER_GENERAL_CLUSTER_CLIENTPRIVATEKEY=/var/hyperledger/orderer/tls/server.key
      - ORDERER_GENERAL_CLUSTER_ROOTCAS=[/var/hyperledger/orderer/tls/ca.crt]
```





CORE_PEER_LOCALMSPID="Org1MSP"

CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp

peer0.org1成员

CORE_PEER_ADDRESS=peer0.org1.example.com:7051 

peer chaincode install -n kpcc -v 1.0 -l golang -p github.com/chaincode/win_test/src/kunpeng_example01/

peer1.org1成员

CORE_PEER_ADDRESS=peer1.org1.example.com:8051

peer chaincode install -n kpcc -v 1.0 -l golang -p github.com/chaincode/win_test/src/kunpeng_example01/



CORE_PEER_LOCALMSPID="Org2MSP"

CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp

peer0.org2成员

CORE_PEER_ADDRESS=peer0.org2.example.com:9051 

peer chaincode install -n kpcc -v 1.0 -l golang -p github.com/chaincode/win_test/src/kunpeng_example01/

peer1.org2成员

CORE_PEER_ADDRESS=peer1.org2.example.com:10051 

peer chaincode install -n kpcc -v 1.0 -l golang -p github.com/chaincode/win_test/src/kunpeng_example01/



peer chaincode instantiate -o orderer.example.com:7050 -C mychannel -n kpcc -l golang -v 1.0 -c '{"Args":[]}' -P 'AND ('\''Org1MSP.peer'\'','\''Org2MSP.peer'\'')'





peer chaincode invoke -o orderer.example.com:7050 -C mychannel -n kpcc -c '{"Args":["invoke","Alice","98","92"]}'

peer chaincode invoke -o orderer.example.com:7050 -C mychannel -n kpcc -c '{"Args":["invoke","Bob","82","97"]}'



peer chaincode query -C mychannel -n kpcc -c '{"Args":["query","Alice"]}'

peer chaincode query -C mychannel -n kpcc -c '{"Args":["query","Bob"]}'



peer chaincode invoke -o orderer.example.com:7050 -C mychannel -n kpcc --peerAddresses peer0.org1.example.com:7051 --peerAddresses peer0.org2.example.com:9051 -c '{"Args":["invoke","Alice","98","93"]}'